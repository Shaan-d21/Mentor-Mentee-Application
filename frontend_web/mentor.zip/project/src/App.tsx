import React, { useState } from 'react';
import { UserCircle2, Users, CheckCircle2 } from 'lucide-react';

// Types
type Skill = {
  name: string;
  expertise: 1 | 2 | 3;
};

type Mentee = {
  id: string;
  name: string;
  email: string;
  course: string[];
  status: 'pending' | 'approved' | 'rejected';
  progress: 'not started' | 'in progress' | 'completed';
};

const PREDEFINED_SKILLS = [
  "JavaScript",
  "Python",
  "Java",
  "C++",
  "React",
  "Node.js",
  "SQL",
  "Machine Learning",
  "Data Science",
  "Cybersecurity"
];

function MentorProfile() {
  const [name, setName] = useState('');
  const [email] = useState('john.doe@example.com');
  const [experience, setExperience] = useState('');
  const [githubProfile, setGithubProfile] = useState('');
  const [skills, setSkills] = useState<Skill[]>([]);
  const [selectedSkill, setSelectedSkill] = useState('');
  const [expertise, setExpertise] = useState<1 | 2 | 3>(1);

  const addSkill = () => {
    if (selectedSkill && !skills.find(s => s.name === selectedSkill)) {
      setSkills([...skills, { name: selectedSkill, expertise }]);
      setSelectedSkill('');
    }
  };

  const removeSkill = (skillName: string) => {
    setSkills(skills.filter(s => s.name !== skillName));
  };

  return (
    <div className="max-w-2xl mx-auto p-6 bg-white rounded-lg shadow-lg">
      <h2 className="text-2xl font-bold mb-6 text-blue-800">Edit Profile</h2>
      
      <div className="space-y-4">
        <div>
          <label className="block text-sm font-medium text-gray-700">Name *</label>
          <input
            type="text"
            value={name}
            onChange={(e) => setName(e.target.value)}
            className="mt-1 block w-full rounded-md border border-gray-300 px-3 py-2"
            required
            placeholder="John Doe"
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700">Email</label>
          <input
            type="email"
            value={email}
            className="mt-1 block w-full rounded-md border border-gray-300 px-3 py-2 bg-gray-100"
            disabled
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700">Years of Experience</label>
          <input
            type="number"
            value={experience}
            onChange={(e) => setExperience(e.target.value)}
            className="mt-1 block w-full rounded-md border border-gray-300 px-3 py-2"
            placeholder="10"
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700">GitHub Profile</label>
          <input
            type="text"
            value={githubProfile}
            onChange={(e) => setGithubProfile(e.target.value)}
            className="mt-1 block w-full rounded-md border border-gray-300 px-3 py-2"
            placeholder="GitHub username"
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700">Skills</label>
          <div className="flex gap-2 mt-1">
            <select
              value={selectedSkill}
              onChange={(e) => setSelectedSkill(e.target.value)}
              className="block w-full rounded-md border border-gray-300 px-3 py-2"
            >
              <option value="">Select a skill</option>
              {PREDEFINED_SKILLS.map(skill => (
                <option key={skill} value={skill}>{skill}</option>
              ))}
            </select>
            <select
              value={expertise}
              onChange={(e) => setExpertise(Number(e.target.value) as 1 | 2 | 3)}
              className="block w-40 rounded-md border border-gray-300 px-3 py-2"
            >
              <option value={1}>Basic (1)</option>
              <option value={2}>Intermediate (2)</option>
              <option value={3}>Expert (3)</option>
            </select>
            <button
              onClick={addSkill}
              className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700"
            >
              Add
            </button>
          </div>
          <div className="mt-2 flex flex-wrap gap-2">
            {skills.map(skill => (
              <div key={skill.name} className="flex items-center gap-1 bg-blue-100 px-3 py-1 rounded-full">
                <span>{skill.name} (Level: {skill.expertise})</span>
                <button
                  onClick={() => removeSkill(skill.name)}
                  className="text-red-600 hover:text-red-800"
                >
                  ×
                </button>
              </div>
            ))}
          </div>
        </div>

        <button className="w-full mt-6 px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700">
          Save Changes
        </button>
      </div>
    </div>
  );
}

function MentorMenteeList() {
  const [mentees] = useState<Mentee[]>([
    {
      id: '1',
      name: 'Priya Sharma',
      email: 'priya.sharma@example.com',
      course: ['JavaScript', 'React'],
      status: 'approved',
      progress: 'not started'
    }
  ]);

  return (
    <div className="max-w-4xl mx-auto p-6">
      <h2 className="text-2xl font-bold mb-6 text-blue-800">Approved Mentees</h2>
      <div className="grid gap-4">
        {mentees.map(mentee => (
          <div key={mentee.id} className="bg-white p-4 rounded-lg shadow-md">
            <div className="flex justify-between items-start">
              <div>
                <h3 className="text-lg font-semibold">{mentee.name}</h3>
                <p className="text-gray-600">{mentee.email}</p>
                <div className="mt-2">
                  <span className="font-medium">Course: </span>
                  {mentee.course.join(', ')}
                </div>
                <div className="mt-2">
                  <span className="font-medium">Progress: </span>
                  <span className="text-yellow-600">{mentee.progress}</span>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

function MentorApprovalPage() {
  const [pendingMentees] = useState<Mentee[]>([
    {
      id: '2',
      name: 'Rahul Verma',
      email: 'rahul.verma@example.com',
      course: ['Python', 'Machine Learning'],
      status: 'pending',
      progress: 'not started'
    }
  ]);

  const handleAction = (id: string, action: 'approve' | 'reject') => {
    console.log(`${action} mentee ${id}`);
  };

  return (
    <div className="max-w-4xl mx-auto p-6">
      <h2 className="text-2xl font-bold mb-6 text-blue-800">Pending Requests</h2>
      <div className="grid gap-4">
        {pendingMentees.map(mentee => (
          <div key={mentee.id} className="bg-white p-4 rounded-lg shadow-md">
            <div className="flex justify-between items-start">
              <div>
                <h3 className="text-lg font-semibold">{mentee.name}</h3>
                <p className="text-gray-600">{mentee.email}</p>
                <div className="mt-2">
                  <span className="font-medium">Course: </span>
                  {mentee.course.join(', ')}
                </div>
              </div>
              <div className="flex gap-2">
                <button
                  onClick={() => handleAction(mentee.id, 'approve')}
                  className="px-4 py-2 bg-green-600 text-white rounded-md hover:bg-green-700"
                >
                  Approve
                </button>
                <button
                  onClick={() => handleAction(mentee.id, 'reject')}
                  className="px-4 py-2 bg-red-600 text-white rounded-md hover:bg-red-700"
                >
                  Reject
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

function App() {
  const [currentPage, setCurrentPage] = useState('profile');

  return (
    <div className="min-h-screen bg-gray-100">
      <nav className="bg-blue-700 text-white p-4">
        <div className="max-w-6xl mx-auto flex justify-between items-center">
          <h1 className="text-2xl font-bold">Mentor-Mentee</h1>
          <div className="flex gap-4">
            <button
              onClick={() => setCurrentPage('profile')}
              className={`flex items-center gap-2 px-4 py-2 rounded-md ${
                currentPage === 'profile' ? 'bg-blue-800' : 'hover:bg-blue-600'
              }`}
            >
              <UserCircle2 size={20} />
              Profile
            </button>
            <button
              onClick={() => setCurrentPage('mentees')}
              className={`flex items-center gap-2 px-4 py-2 rounded-md ${
                currentPage === 'mentees' ? 'bg-blue-800' : 'hover:bg-blue-600'
              }`}
            >
              <Users size={20} />
              My Mentees
            </button>
            <button
              onClick={() => setCurrentPage('approval')}
              className={`flex items-center gap-2 px-4 py-2 rounded-md ${
                currentPage === 'approval' ? 'bg-blue-800' : 'hover:bg-blue-600'
              }`}
            >
              <CheckCircle2 size={20} />
              Approve Requests
            </button>
          </div>
        </div>
      </nav>

      <main className="max-w-6xl mx-auto py-8">
        {currentPage === 'profile' && <MentorProfile />}
        {currentPage === 'mentees' && <MentorMenteeList />}
        {currentPage === 'approval' && <MentorApprovalPage />}
      </main>
    </div>
  );
}

export default App;