from datetime import datetime, timedelta, timezone
from typing import Annotated
from fastapi import APIRouter, Depends, HTTPException, Header
from pydantic import BaseModel
from models import User
from database import SessionLocal
from sqlalchemy.orm import Session
from fastapi.security import OAuth2PasswordRequestForm, OAuth2PasswordBearer
from jose import jwt, JWTError
from starlette import status
from passlib.context import CryptContext
from enum import Enum
router = APIRouter(
    prefix='/authentication',
    tags=['authentication']
)
SECRET_KEY = 'f7458ea66f73cac978f1233a9c9622dd8795bc98a59b2bd26622b58872212385'
ALGORITHM = 'HS256'
bcrypt_context = CryptContext(schemes=['bcrypt'], deprecated='auto')
o2auth_bearer = OAuth2PasswordBearer(tokenUrl='authentication/login')
class Roles(str, Enum):
    mentor = 'mentor'
    mentee = 'mentee'
    admin = 'admin'
class Create_User_Request(BaseModel):
    name: str
    mail: str
    pwd: str
    role: Roles
    
class Login_Request(BaseModel):
    email : str
    password: str

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
db_dependency = Annotated[Session, Depends(get_db)]

def authenticate_user(email: str, password: str, db: Session):
    user = db.query(User).filter(User.mail == email).first()
    if user is None or not bcrypt_context.verify(password, user.pwd):
        return None
    return user

def user_access_token(email: str, user_id: int, role: str, expires_delta: timedelta):
    encode = {'sub': email, 'id': user_id, 'role': role.value}
    expiry = datetime.now(timezone.utc) + expires_delta
    encode.update({'exp': expiry})
    return jwt.encode(encode, SECRET_KEY, algorithm=ALGORITHM)

# async def get_current_user(token: str = Depends(Header(...))):
#     try:
#         payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
#         mail: str = payload.get('sub')
#         user_id: int = payload.get('id')
#         role: str = payload.get('role')
#         if mail is None or user_id is None:
#             raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail='User not found')
#         return {'email': mail, 'user_id': user_id, 'role': role}
#     except JWTError:
#         raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail='Invalid token')

async def get_current_user(token: str = Header(None, alias="Authorization")):
    try:
        if token is None:
            raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail='No token provided')
        
        print(f"Received token: {token[:20]}...")  # Debug log
        
        # Extract the token if it has a Bearer prefix
        if token.startswith('Bearer '):
            token = token.split('Bearer ')[1].strip()
            print(f"Extracted token without Bearer: {token[:20]}...")  # Debug log
        
        if not token:
            raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail='Empty token after extraction')
            
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        mail: str = payload.get('sub')
        user_id: int = payload.get('id')
        role: str = payload.get('role')
        if mail is None or user_id is None:
            raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail='User not found in token payload')
        return {'email': mail, 'user_id': user_id, 'role': role}
    except JWTError as e:
        print(f"JWT Error: {str(e)}")
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail=f'Invalid token: {str(e)}')
    except Exception as e:
        # Log the error
        print(f"Token error: {str(e)}")
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail=f'Token error: {str(e)}')





# Login form
@router.post('/login')
async def login_for_access_token(form_data : Annotated[OAuth2PasswordRequestForm, Depends()], db : db_dependency):
    user = authenticate_user(form_data.username, form_data.password, db)
    if not user:
        raise HTTPException(status_code=404, detail='User not found')
    token = user_access_token(user.name, user.id, user.role, timedelta(minutes=20000))
    return {'access_token' : token, 'token_type' : 'bearer', 'role': user.role, 'user_name' : user.name, 'status_code' : 200, 'profile_status': user.is_profile_complete}